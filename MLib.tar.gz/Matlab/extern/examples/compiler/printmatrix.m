function printmatrix(m)

% Copyright 2004 The MathWorks, Inc.

    disp(m);
