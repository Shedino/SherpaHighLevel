function hello
% This is the hello, world function written in MATLAB code

% Copyright 2011 The MathWorks, Inc.
%
        fprintf(1,'Hello, World\n' );

